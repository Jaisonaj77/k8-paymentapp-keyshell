// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms'; // Import FormsModule for ngModel
// import { PaymentFormComponent } from './payment-form.component';

// @NgModule({
//   declarations: [PaymentFormComponent],
//   imports: [
//     CommonModule,
//     FormsModule // Add FormsModule to imports
//   ],
//   exports: [PaymentFormComponent] // Export if you plan to use this component elsewhere
// })
// export class PaymentFormModule { }
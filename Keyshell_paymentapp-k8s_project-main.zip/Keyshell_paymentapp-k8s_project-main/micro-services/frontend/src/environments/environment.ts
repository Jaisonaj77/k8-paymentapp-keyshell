export const environment = {
    production: false,
    apiUrl: 'http://localhost:80/api',
    authServiceUrl: 'http://localhost:80/api/auth',
    paymentServiceUrl: 'http://localhost:80/api/payments'
  };